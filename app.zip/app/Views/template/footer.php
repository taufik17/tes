<footer class="main-footer">
	<div class="footer-left">
		Ujikom
	</div>
	<div class="footer-right">
		Versi: Ujikom
	</div>
</footer>
